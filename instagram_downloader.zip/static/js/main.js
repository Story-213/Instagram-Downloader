document.addEventListener('DOMContentLoaded', function() {
    const downloadForm = document.getElementById('downloadForm');
    const urlInput = document.getElementById('urlInput');
    const downloadBtn = document.getElementById('downloadBtn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const previewArea = document.getElementById('previewArea');
    const videoPreview = document.getElementById('videoPreview');
    const alertArea = document.getElementById('alertArea');

    // Add event listener for paste
    urlInput.addEventListener('paste', function(e) {
        // Clear any existing alerts
        alertArea.innerHTML = '';
        // Add visual feedback
        showAlert('URL pasted! Click Download to proceed.', 'info');
    });

    function showAlert(message, type = 'danger') {
        alertArea.innerHTML = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
    }

    function setLoading(isLoading) {
        loadingSpinner.classList.toggle('d-none', !isLoading);
        downloadBtn.disabled = isLoading;
        urlInput.disabled = isLoading;
        if (isLoading) {
            previewArea.classList.add('d-none');
            showAlert('Downloading video, please wait...', 'info');
        }
    }

    downloadForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        const url = urlInput.value.trim();
        if (!url) {
            showAlert('Please enter a valid Instagram video URL');
            return;
        }

        // Validate if it's an Instagram URL
        if (!url.includes('instagram.com')) {
            showAlert('Please enter a valid Instagram URL');
            return;
        }

        setLoading(true);
        alertArea.innerHTML = '';

        try {
            const formData = new FormData();
            formData.append('url', url);

            const response = await fetch('/download', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                previewArea.classList.remove('d-none');
                videoPreview.src = data.video_url;
                showAlert('Video downloaded successfully!', 'success');
                urlInput.value = ''; // Clear the input after successful download
            } else {
                showAlert(data.error || 'Failed to download video');
            }
        } catch (error) {
            console.error('Error:', error);
            showAlert('An error occurred while processing your request. Please try again.');
        } finally {
            setLoading(false);
        }
    });
});