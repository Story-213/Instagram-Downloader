# Instagram Video Downloader

A web application that allows users to easily download Instagram videos with a simple interface, featuring dark/light mode toggle.

## Features
- Instagram video download functionality
- Dark/Light mode toggle
- Video preview
- Progress feedback
- Download history tracking

## Requirements
- Python 3.8+
- Flask
- instaloader
- Flask-SQLAlchemy
- Bootstrap 5 (CDN included)

## Installation

1. Clone the repository
2. Install dependencies:
```bash
pip install flask instaloader flask-sqlalchemy
```

3. Create a downloads directory:
```bash
mkdir static/downloads
```

4. Run the application:
```bash
python main.py
```

The application will be available at `http://localhost:5000`

## Usage
1. Copy an Instagram video URL
2. Paste it into the input field
3. Click "Download"
4. Wait for the video to process
5. Preview and download the video

## File Structure
```
├── app.py              # Main Flask application
├── main.py            # Application entry point
├── models.py          # Database models
├── utils/
│   └── instagram.py   # Instagram download utilities
├── static/
│   ├── css/
│   │   └── style.css  # Custom styles
│   └── js/
│       ├── main.js    # Main JavaScript
│       └── theme.js   # Theme toggle functionality
└── templates/
    └── index.html     # Main template
```

## Environment Variables
- `DATABASE_URL`: Database connection string (optional, defaults to SQLite)
- `FLASK_SECRET_KEY`: Secret key for Flask session (optional)

## License
MIT License
