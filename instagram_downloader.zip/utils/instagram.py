import os
import instaloader
import logging
from urllib.parse import urlparse
import glob

logger = logging.getLogger(__name__)

def download_instagram_video(url, download_path):
    try:
        # Initialize instaloader
        L = instaloader.Instaloader(dirname_pattern=download_path,
                                  download_pictures=False,
                                  download_videos=True,
                                  download_video_thumbnails=False,
                                  save_metadata=False)

        # Parse the URL to get the shortcode
        path = urlparse(url).path
        shortcode = path.split('/')[-2] if path.split('/')[-1] == '' else path.split('/')[-1]
        logger.debug(f"Extracted shortcode: {shortcode}")

        # Get post by shortcode
        post = instaloader.Post.from_shortcode(L.context, shortcode)

        if post.is_video:
            # Download the video
            logger.debug(f"Downloading video to: {download_path}")
            L.download_post(post, target=download_path)

            # Find the downloaded video file (most recent .mp4 file)
            video_files = glob.glob(os.path.join(download_path, '*.mp4'))
            if video_files:
                latest_video = max(video_files, key=os.path.getctime)
                video_filename = os.path.basename(latest_video)
                logger.debug(f"Found downloaded video: {video_filename}")
                return f"downloads/{video_filename}"
            else:
                logger.error("No video file found after download")
                return None
        else:
            logger.error("The provided URL is not a video post")
            return None

    except Exception as e:
        logger.error(f"Error downloading Instagram video: {str(e)}")
        return None